plugins {
    id("com.android.application")
}

android {
    namespace = "com.kota.daily.routine"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.kota.daily.routine"
        minSdk = 23
        targetSdk = 35
        versionCode = 1
        versionName = "1.0"
    }

    buildTypes {
        release {
            minifyEnabled = false
            shrinkResources = false
        }
    }
}

dependencies {
    implementation("androidx.appcompat:appcompat:1.7.0")
    implementation("androidx.webkit:webkit:1.12.1")
}
