# KOTA'S DAILY ROUTINE — Android APK

This is the Android WebView version of KOTA'S DAILY ROUTINE.

## PDF upload fix
The app includes a native Android `ACTION_OPEN_DOCUMENT` PDF picker through `WebChromeClient.onShowFileChooser`. Tap Books → Choose/Upload PDF → select a PDF from the Android Files picker.

## Build without a laptop
This project includes `.github/workflows/build-apk.yml` so it can be built with GitHub Actions from an iPad.

1. Create a new GitHub repository.
2. Upload all files/folders from this project to the repository (preserve the `.github/workflows` folder).
3. Open the repository's **Actions** tab.
4. Choose **Build KOTA Daily Routine APK**.
5. Tap **Run workflow**.
6. After it finishes, open the workflow run and download the artifact named **KOTA-Daily-Routine-debug-APK**.
7. Extract the ZIP and install `app-debug.apk` on Android.

The Supabase publishable key used by the HTML is a client-side publishable key, not a service-role secret.
